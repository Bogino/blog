package main.model;


public enum ModerationStatus {

    NEW,
    ACCEPTED,
    DECLINED

}
