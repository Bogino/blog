package main.api.response;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class ApiPostResponse {

    private int count;
    private List<PostResponse> posts;
}

@Data
@AllArgsConstructor
class PostResponse {

    private int id;
    private long timestamp;
    private UserIdNameResponse userIdNameResponse;
    private String title;
    private String announce;
    private int likeCount;
    private int dislikeCount;
    private int commentCount;
    private int viewCount;
}

@Data
@AllArgsConstructor
class UserIdNameResponse {

    private int id;
    private String name;
}

